package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.IosApp
import com.example.ui.apps.*
import com.example.ui.components.ControlCenter
import com.example.ui.components.HomeScreen
import com.example.ui.components.LockScreen
import com.example.ui.components.SpotlightSearch
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.IosSystemViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    IosPhoneContainer()
                }
            }
        }
    }
}

@Composable
fun IosPhoneContainer(
    viewModel: IosSystemViewModel = viewModel()
) {
    val isLocked by viewModel.isLocked.collectAsState()
    val currentApp by viewModel.currentApp.collectAsState()
    val isControlCenterOpen by viewModel.isControlCenterOpen.collectAsState()
    val isSpotlightOpen by viewModel.isSpotlightOpen.collectAsState()

    // Android back button handling
    BackHandler(enabled = isControlCenterOpen || isSpotlightOpen || currentApp != null) {
        when {
            isControlCenterOpen -> viewModel.closeControlCenter()
            isSpotlightOpen -> viewModel.closeSpotlight()
            currentApp != null -> viewModel.goHome()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .safeDrawingPadding()
    ) {
        if (isLocked) {
            LockScreen(viewModel = viewModel)
        } else {
            // Main OS surface
            AnimatedContent(
                targetState = currentApp,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "app_transition"
            ) { targetApp ->
                when (targetApp) {
                    null -> HomeScreen(viewModel = viewModel)
                    IosApp.PHONE -> PhoneApp(viewModel = viewModel)
                    IosApp.MESSAGES -> MessagesApp(viewModel = viewModel)
                    IosApp.SAFARI -> SafariApp(viewModel = viewModel)
                    IosApp.CAMERA -> CameraApp(viewModel = viewModel)
                    IosApp.CALCULATOR -> CalculatorApp(viewModel = viewModel)
                    IosApp.WEATHER -> WeatherApp(viewModel = viewModel)
                    IosApp.MUSIC -> MusicApp(viewModel = viewModel)
                    IosApp.NOTES -> NotesApp(viewModel = viewModel)
                    IosApp.CLOCK -> ClockApp(viewModel = viewModel)
                    IosApp.SETTINGS -> SettingsApp(viewModel = viewModel)
                    IosApp.PHOTOS -> PhotosApp(viewModel = viewModel)
                    IosApp.HEALTH -> HealthApp(viewModel = viewModel)
                    IosApp.MAPS -> MapsApp(viewModel = viewModel)
                    IosApp.CALENDAR -> ClockApp(viewModel = viewModel)
                    IosApp.REMINDERS -> NotesApp(viewModel = viewModel)
                    IosApp.APP_STORE -> AppStoreApp(viewModel = viewModel)
                }
            }

            // Top-Right Swipe-Down Touch Zone for Control Center
            if (!isControlCenterOpen && !isSpotlightOpen) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .fillMaxWidth(0.5f)
                        .height(68.dp)
                        .pointerInput(Unit) {
                            var dragDistanceY = 0f
                            detectDragGestures(
                                onDragStart = { dragDistanceY = 0f },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    dragDistanceY += dragAmount.y
                                    if (dragDistanceY > 20f) {
                                        viewModel.openControlCenter()
                                    }
                                }
                            )
                        }
                )
            }

            // Spotlight Search Overlay
            AnimatedVisibility(
                visible = isSpotlightOpen,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 2 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 2 })
            ) {
                SpotlightSearch(viewModel = viewModel)
            }

            // Swipe-Down Control Center Overlay
            AnimatedVisibility(
                visible = isControlCenterOpen,
                enter = fadeIn(animationSpec = tween(180)) + slideInVertically(
                    initialOffsetY = { -it },
                    animationSpec = spring(
                        stiffness = Spring.StiffnessMediumLow,
                        dampingRatio = Spring.DampingRatioLowBouncy
                    )
                ),
                exit = fadeOut(animationSpec = tween(160)) + slideOutVertically(
                    targetOffsetY = { -it },
                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                )
            ) {
                ControlCenter(viewModel = viewModel)
            }
        }
    }
}
