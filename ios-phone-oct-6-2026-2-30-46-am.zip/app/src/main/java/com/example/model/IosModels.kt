package com.example.model

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

enum class IosApp(val title: String, val badgeCount: Int = 0) {
    PHONE("Phone", 1),
    MESSAGES("Messages", 3),
    SAFARI("Safari"),
    MUSIC("Music"),
    CAMERA("Camera"),
    PHOTOS("Photos"),
    WEATHER("Weather"),
    CLOCK("Clock"),
    CALCULATOR("Calculator"),
    NOTES("Notes"),
    SETTINGS("Settings"),
    MAPS("Maps"),
    HEALTH("Health"),
    CALENDAR("Calendar"),
    REMINDERS("Reminders"),
    APP_STORE("App Store")
}

enum class DynamicIslandMode {
    COMPACT,
    CALLING,
    MUSIC,
    TIMER,
    BATTERY
}

data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val avatarColor: Color,
    val callType: String = "Mobile",
    val recentTime: String = "Yesterday"
)

data class ChatMessage(
    val id: String,
    val sender: String,
    val text: String,
    val time: String,
    val isFromMe: Boolean,
    val reaction: String? = null
)

data class NoteItem(
    val id: String,
    val title: String,
    val content: String,
    val timestamp: String,
    val isPinned: Boolean = false
)

data class AlarmItem(
    val id: String,
    val time: String,
    val period: String,
    val label: String,
    val isEnabled: Boolean
)

data class TrackInfo(
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int = 214
)

data class NotificationItem(
    val id: String,
    val app: IosApp,
    val title: String,
    val message: String,
    val timeAgo: String
)
