package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun CalculatorApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val display by viewModel.calcDisplay.collectAsState()

    val buttons = listOf(
        listOf("AC" to Color(0xFFA5A5A5), "+/-" to Color(0xFFA5A5A5), "%" to Color(0xFFA5A5A5), "÷" to IosColors.SystemOrange),
        listOf("7" to Color(0xFF333333), "8" to Color(0xFF333333), "9" to Color(0xFF333333), "×" to IosColors.SystemOrange),
        listOf("4" to Color(0xFF333333), "5" to Color(0xFF333333), "6" to Color(0xFF333333), "-" to IosColors.SystemOrange),
        listOf("1" to Color(0xFF333333), "2" to Color(0xFF333333), "3" to Color(0xFF333333), "+" to IosColors.SystemOrange)
    )

    Box(
        modifier = modifier
            .testTag("calculator_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            IosStatusBar(viewModel = viewModel)

            // Result Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Text(
                    text = display,
                    color = Color.White,
                    fontSize = if (display.length > 7) 48.sp else 74.sp,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.End,
                    maxLines = 1
                )
            }

            // Button Keypad
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                buttons.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEach { (text, color) ->
                            CalcButton(
                                text = text,
                                backgroundColor = color,
                                textColor = if (color == Color(0xFFA5A5A5)) Color.Black else Color.White,
                                modifier = Modifier.weight(1f),
                                onClick = { viewModel.onCalcInput(text) }
                            )
                        }
                    }
                }

                // Bottom row: "0" (wide button) and "." and "="
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Wide "0" Button
                    Box(
                        modifier = Modifier
                            .weight(2f)
                            .height(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF333333))
                            .clickable { viewModel.onCalcInput("0") }
                            .padding(start = 28.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = "0",
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }

                    // "." button
                    CalcButton(
                        text = ".",
                        backgroundColor = Color(0xFF333333),
                        textColor = Color.White,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onCalcInput(".") }
                    )

                    // "=" button
                    CalcButton(
                        text = "=",
                        backgroundColor = IosColors.SystemOrange,
                        textColor = Color.White,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.onCalcInput("=") }
                    )
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
private fun CalcButton(
    text: String,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(CircleShape)
            .background(backgroundColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 30.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
