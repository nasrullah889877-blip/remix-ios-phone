package com.example.ui.apps

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.IosApp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel
import kotlinx.coroutines.delay

@Composable
fun CameraApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    var selectedMode by remember { mutableStateOf("PHOTO") }
    var selectedZoom by remember { mutableStateOf("1x") }
    var isFlashOn by remember { mutableStateOf(false) }
    var isShutterTriggered by remember { mutableStateOf(false) }

    LaunchedEffect(isShutterTriggered) {
        if (isShutterTriggered) {
            delay(150)
            isShutterTriggered = false
        }
    }

    Box(
        modifier = modifier
            .testTag("camera_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            // Top Camera Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { isFlashOn = !isFlashOn }) {
                    Icon(
                        imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash",
                        tint = if (isFlashOn) IosColors.SystemYellow else Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x44FFFFFF))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("4K • 60", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(onClick = {}) {
                    Icon(
                        imageVector = Icons.Default.MotionPhotosOn,
                        contentDescription = "Live Photo",
                        tint = Color.White
                    )
                }
            }

            // Viewfinder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF18181A)),
                contentAlignment = Alignment.Center
            ) {
                // Background artistic preview image
                Image(
                    painter = painterResource(id = R.drawable.ios_wallpaper_1791234495056),
                    contentDescription = "Viewfinder Feed",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Shutter flash whiteout
                if (isShutterTriggered) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White)
                    )
                }

                // Focus reticle
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .border(1.5.dp, IosColors.SystemYellow, RoundedCornerShape(8.dp))
                )

                // Zoom control pill (.5, 1x, 2x, 3x)
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x66000000))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    listOf(".5", "1x", "2x", "3x").forEach { zoom ->
                        Text(
                            text = zoom,
                            color = if (selectedZoom == zoom) IosColors.SystemYellow else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { selectedZoom = zoom }
                        )
                    }
                }
            }

            // Camera Modes (SLO-MO, VIDEO, PHOTO, PORTRAIT, PANO)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("CINEMATIC", "VIDEO", "PHOTO", "PORTRAIT", "PANO").forEach { mode ->
                    Text(
                        text = mode,
                        color = if (selectedMode == mode) IosColors.SystemYellow else Color(0x99FFFFFF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.clickable { selectedMode = mode }
                    )
                }
            }

            // Bottom Shutter & Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Recent Photo Thumbnail
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2C2C2E))
                        .clickable { viewModel.openApp(IosApp.PHOTOS) },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ios_album_art_1791234504932),
                        contentDescription = "Recent Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Shutter Button (Outer ring + White circle)
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(if (selectedMode == "VIDEO") IosColors.SystemRed else Color.White)
                        .clickable { isShutterTriggered = true }
                )

                // Flip Camera Button
                IconButton(
                    onClick = {},
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                ) {
                    Icon(
                        imageVector = Icons.Default.FlipCameraIos,
                        contentDescription = "Flip Camera",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}
