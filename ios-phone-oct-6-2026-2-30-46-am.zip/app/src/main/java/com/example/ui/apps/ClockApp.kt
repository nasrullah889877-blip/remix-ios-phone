package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel
import kotlinx.coroutines.delay

@Composable
fun ClockApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(2) } // 0: World Clock, 1: Alarm, 2: Stopwatch, 3: Timer

    Box(
        modifier = modifier
            .testTag("clock_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> WorldClockTab()
                    1 -> AlarmTab(viewModel = viewModel)
                    2 -> StopwatchTab()
                    3 -> TimerTab(viewModel = viewModel)
                }
            }

            // Bottom Navigation Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161616))
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                val tabs = listOf(
                    Icons.Default.Public to "World Clock",
                    Icons.Default.Alarm to "Alarm",
                    Icons.Default.Timer to "Stopwatch",
                    Icons.Default.HourglassBottom to "Timer"
                )
                tabs.forEachIndexed { index, (icon, label) ->
                    val isSelected = selectedTab == index
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedTab = index }
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) IosColors.SystemOrange else IosColors.SystemGray,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = label,
                            color = if (isSelected) IosColors.SystemOrange else IosColors.SystemGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
private fun WorldClockTab() {
    val cities = listOf(
        Pair("Cupertino", "Today, -0HRS" to "9:41 AM"),
        Pair("Tokyo", "Tomorrow, +16HRS" to "1:41 AM"),
        Pair("London", "Today, +8HRS" to "5:41 PM"),
        Pair("Paris", "Today, +9HRS" to "6:41 PM"),
        Pair("New York", "Today, +3HRS" to "12:41 PM")
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("World Clock", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(cities) { (city, details) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(details.first, color = IosColors.SystemGray, fontSize = 12.sp)
                        Text(city, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text(details.second, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                }
                HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(top = 12.dp))
            }
        }
    }
}

@Composable
private fun AlarmTab(viewModel: IosSystemViewModel) {
    val alarms by viewModel.alarms.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Alarms", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(alarms) { alarm ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = alarm.time,
                                color = if (alarm.isEnabled) Color.White else IosColors.SystemGray,
                                fontSize = 48.sp,
                                fontWeight = FontWeight.Light
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = alarm.period,
                                color = if (alarm.isEnabled) Color.White else IosColors.SystemGray,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                        Text(alarm.label, color = IosColors.SystemGray, fontSize = 13.sp)
                    }
                    Switch(
                        checked = alarm.isEnabled,
                        onCheckedChange = { viewModel.toggleAlarm(alarm.id) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = IosColors.SystemGreen,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0xFF39393D)
                        )
                    )
                }
                HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}

@Composable
private fun StopwatchTab() {
    var isRunning by remember { mutableStateOf(false) }
    var elapsedMillis by remember { mutableLongStateOf(0L) }
    var laps by remember { mutableStateOf(listOf<Long>()) }

    LaunchedEffect(isRunning) {
        if (isRunning) {
            val startTime = System.currentTimeMillis() - elapsedMillis
            while (isRunning) {
                delay(30)
                elapsedMillis = System.currentTimeMillis() - startTime
            }
        }
    }

    val minutes = (elapsedMillis / 60000)
    val seconds = (elapsedMillis % 60000) / 1000
    val millis = (elapsedMillis % 1000) / 10

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(30.dp))
        Text(
            text = String.format("%02d:%02d.%02d", minutes, seconds, millis),
            color = Color.White,
            fontSize = 68.sp,
            fontWeight = FontWeight.Thin
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Lap & Start/Stop Buttons
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Lap / Reset Button
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF333333))
                    .clickable {
                        if (isRunning) {
                            laps = listOf(elapsedMillis) + laps
                        } else {
                            elapsedMillis = 0L
                            laps = emptyList()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(if (isRunning) "Lap" else "Reset", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }

            // Start / Stop Button
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(if (isRunning) Color(0x44FF3B30) else Color(0x4434C759))
                    .clickable { isRunning = !isRunning },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isRunning) "Stop" else "Start",
                    color = if (isRunning) IosColors.SystemRed else IosColors.SystemGreen,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Lap Times List
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(laps) { lapTime ->
                val lapMin = (lapTime / 60000)
                val lapSec = (lapTime % 60000) / 1000
                val lapMil = (lapTime % 1000) / 10
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Lap", color = Color.White, fontSize = 16.sp)
                    Text(String.format("%02d:%02d.%02d", lapMin, lapSec, lapMil), color = Color.White, fontSize = 16.sp)
                }
                HorizontalDivider(color = Color(0x1AFFFFFF))
            }
        }
    }
}

@Composable
private fun TimerTab(viewModel: IosSystemViewModel) {
    val remaining by viewModel.timerRemainingSeconds.collectAsState()
    val isRunning by viewModel.isTimerRunning.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = String.format("%02d:%02d", remaining / 60, remaining % 60),
                color = Color.White,
                fontSize = 72.sp,
                fontWeight = FontWeight.Thin
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isRunning) "Timer active on Dynamic Island" else "Ready to start",
                color = IosColors.SystemOrange,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF333333))
                    .clickable { viewModel.cancelTimer() },
                contentAlignment = Alignment.Center
            ) {
                Text("Cancel", color = Color.White, fontSize = 16.sp)
            }

            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(if (isRunning) Color(0x44FF9500) else Color(0x4434C759))
                    .clickable {
                        if (isRunning) viewModel.pauseResumeTimer() else viewModel.startTimer(180)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isRunning) "Pause" else "Start 3m",
                    color = if (isRunning) IosColors.SystemOrange else IosColors.SystemGreen,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
