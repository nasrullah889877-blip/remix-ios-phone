package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Contact
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun PhoneApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val isInCall by viewModel.isInCall.collectAsState()
    val callName by viewModel.callContactName.collectAsState()
    val callDuration by viewModel.callDurationSeconds.collectAsState()
    val dialedNumber by viewModel.dialedNumber.collectAsState()
    val contacts by viewModel.contacts.collectAsState()

    var selectedTab by remember { mutableStateOf(3) } // 0: Favorites, 1: Recents, 2: Contacts, 3: Keypad, 4: Voicemail

    Box(
        modifier = modifier
            .testTag("phone_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (isInCall) {
            // IN-CALL SCREEN
            InCallScreen(
                name = callName,
                durationSeconds = callDuration,
                onEndCall = { viewModel.endCall() }
            )
        } else {
            // MAIN PHONE UI
            Column(modifier = Modifier.fillMaxSize()) {
                IosStatusBar(viewModel = viewModel)

                // Tab Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        1 -> RecentsTab(contacts = contacts, onCall = { name, phone -> viewModel.startCall(name, phone) })
                        2 -> ContactsTab(contacts = contacts, onCall = { name, phone -> viewModel.startCall(name, phone) })
                        3 -> KeypadTab(
                            dialedNumber = dialedNumber,
                            onDigit = { viewModel.appendDial(it) },
                            onBackspace = { viewModel.backspaceDial() },
                            onCall = { viewModel.startCall(if (dialedNumber.isEmpty()) "Quick Dial" else dialedNumber, dialedNumber) }
                        )
                        else -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No Voicemails", color = IosColors.SystemGray, fontSize = 17.sp)
                            }
                        }
                    }
                }

                // Bottom Tab Bar
                PhoneTabBar(
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it }
                )

                HomeBar(onHomeClick = { viewModel.goHome() })
            }
        }
    }
}

@Composable
private fun InCallScreen(
    name: String,
    durationSeconds: Int,
    onEndCall: () -> Unit
) {
    var isMuted by remember { mutableStateOf(false) }
    var isSpeaker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Caller Info
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 40.dp)
        ) {
            Text(
                text = name,
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60),
                color = IosColors.SystemGray,
                fontSize = 17.sp
            )
        }

        // 3x2 In-Call Actions
        Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                InCallCircleButton(
                    icon = Icons.Default.MicOff,
                    label = "mute",
                    isActive = isMuted,
                    onClick = { isMuted = !isMuted }
                )
                InCallCircleButton(
                    icon = Icons.Default.Dialpad,
                    label = "keypad",
                    onClick = {}
                )
                InCallCircleButton(
                    icon = Icons.Default.VolumeUp,
                    label = "audio",
                    isActive = isSpeaker,
                    onClick = { isSpeaker = !isSpeaker }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                InCallCircleButton(icon = Icons.Default.Add, label = "add call", onClick = {})
                InCallCircleButton(icon = Icons.Default.Videocam, label = "FaceTime", onClick = {})
                InCallCircleButton(icon = Icons.Default.AccountCircle, label = "contacts", onClick = {})
            }
        }

        // End Call Button
        IconButton(
            onClick = onEndCall,
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(IosColors.SystemRed)
        ) {
            Icon(
                imageVector = Icons.Default.CallEnd,
                contentDescription = "End Call",
                tint = Color.White,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}

@Composable
private fun InCallCircleButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean = false,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(if (isActive) Color.White else Color(0x33FFFFFF))
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) Color.Black else Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun KeypadTab(
    dialedNumber: String,
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    onCall: () -> Unit
) {
    val keypadRows = listOf(
        listOf("1" to "", "2" to "A B C", "3" to "D E F"),
        listOf("4" to "G H I", "5" to "J K L", "6" to "M N O"),
        listOf("7" to "P Q R S", "8" to "T U V", "9" to "W X Y Z"),
        listOf("*" to "", "0" to "+", "#" to "")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        // Dialed number display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = dialedNumber,
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
        }

        // Keypad grid
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            keypadRows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { (num, sub) ->
                        KeypadButton(digit = num, subtitle = sub, onClick = { onDigit(num) })
                    }
                }
            }

            // Bottom call row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.size(72.dp))
                // Green Call Button
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(IosColors.SystemGreen)
                        .clickable { onCall() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }

                // Backspace button
                if (dialedNumber.isNotEmpty()) {
                    IconButton(
                        onClick = onBackspace,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Backspace,
                            contentDescription = "Backspace",
                            tint = IosColors.SystemGray,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(72.dp))
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    digit: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Color(0xFF333333))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = digit,
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Normal
            )
            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun RecentsTab(
    contacts: List<Contact>,
    onCall: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "Recents",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 12.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(contacts) { contact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onCall(contact.name, contact.phone) }
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(contact.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(contact.callType, color = IosColors.SystemGray, fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(contact.recentTime, color = IosColors.SystemGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Info, contentDescription = "Info", tint = IosColors.SystemBlue, modifier = Modifier.size(20.dp))
                    }
                }
                HorizontalDivider(color = Color(0x22FFFFFF))
            }
        }
    }
}

@Composable
private fun ContactsTab(
    contacts: List<Contact>,
    onCall: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "Contacts",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 12.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(contacts) { contact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onCall(contact.name, contact.phone) }
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(contact.avatarColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = contact.name.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(contact.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(contact.phone, color = IosColors.SystemGray, fontSize = 13.sp)
                    }
                }
                HorizontalDivider(color = Color(0x1AFFFFFF))
            }
        }
    }
}

@Composable
private fun PhoneTabBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161616))
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        val tabs = listOf(
            Icons.Default.Star to "Favorites",
            Icons.Default.Schedule to "Recents",
            Icons.Default.AccountCircle to "Contacts",
            Icons.Default.Dialpad to "Keypad",
            Icons.Default.Voicemail to "Voicemail"
        )
        tabs.forEachIndexed { index, (icon, label) ->
            val isSelected = selectedTab == index
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onTabSelected(index) }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) IosColors.SystemBlue else IosColors.SystemGray,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = label,
                    color = if (isSelected) IosColors.SystemBlue else IosColors.SystemGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
