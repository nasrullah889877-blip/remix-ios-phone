package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun SafariApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    var urlText by remember { mutableStateOf("apple.com") }
    var currentTitle by remember { mutableStateOf("Apple") }

    val bookmarks = listOf(
        "Apple" to "apple.com",
        "Developer" to "developer.apple.com",
        "News" to "news.apple.com",
        "Weather" to "weather.com",
        "GitHub" to "github.com"
    )

    Box(
        modifier = modifier
            .testTag("safari_app")
            .fillMaxSize()
            .background(Color(0xFF0F0F10))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            // Web Content Area
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Favorites",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        bookmarks.forEach { (title, url) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    urlText = url
                                    currentTitle = title
                                }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFF242426)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = title.take(2).uppercase(),
                                        color = IosColors.SystemBlue,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(title, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }

                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF1C1C1E))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = IosColors.SystemGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Privacy Report", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Safari has prevented 42 trackers across websites from profiling you in the last 30 days.",
                                color = IosColors.SystemGray,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF1C1C1E))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("Reading List", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("WWDC 2026: What's New in Spatial Computing & Neural Intelligence", color = IosColors.SystemBlue, fontSize = 14.sp)
                            Text("developer.apple.com • Saved 2 hours ago", color = IosColors.SystemGray, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Safari Bottom Floating URL Pill & Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF242426))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FormatSize, contentDescription = "Reader", tint = IosColors.SystemGray, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Secure", tint = Color(0x99FFFFFF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = urlText,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = IosColors.SystemGray, modifier = Modifier.size(20.dp))
                }
            }

            // Safari Toolbar (Back, Forward, Share, Tabs)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161616))
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = IosColors.SystemBlue)
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Forward", tint = IosColors.SystemGray)
                Icon(Icons.Default.Share, contentDescription = "Share", tint = IosColors.SystemBlue)
                Icon(Icons.Default.Book, contentDescription = "Bookmarks", tint = IosColors.SystemBlue)
                Icon(Icons.Default.Layers, contentDescription = "Tabs", tint = IosColors.SystemBlue)
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}
