package com.example.ui.apps

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun PhotosApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("photos_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Library", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("Select", color = IosColors.SystemBlue, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            // Photo Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(15) { index ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .background(Color(0xFF202022))
                    ) {
                        Image(
                            painter = painterResource(
                                id = if (index % 2 == 0) R.drawable.ios_wallpaper_1791234495056 else R.drawable.ios_album_art_1791234504932
                            ),
                            contentDescription = "Photo $index",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
fun HealthApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("health_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Summary", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }

                // Activity Rings Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF1C1C1E))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Activity", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.DirectionsRun, contentDescription = null, tint = IosColors.SystemPink)
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                HealthStatItem("MOVE", "540/600", "CAL", IosColors.SystemPink)
                                HealthStatItem("EXERCISE", "38/30", "MIN", IosColors.SystemGreen)
                                HealthStatItem("STAND", "10/12", "HRS", IosColors.SystemTeal)
                            }
                        }
                    }
                }

                // Steps & Distance
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF1C1C1E))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text("STEPS", color = IosColors.SystemOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("8,420", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                Text("Goal: 10,000", color = IosColors.SystemGray, fontSize = 12.sp)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF1C1C1E))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text("HEART RATE", color = IosColors.SystemRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("72", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                Text("BPM • Resting", color = IosColors.SystemGray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
private fun HealthStatItem(title: String, value: String, unit: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(unit, color = IosColors.SystemGray, fontSize = 10.sp)
    }
}

@Composable
fun MapsApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("maps_app")
            .fillMaxSize()
            .background(Color(0xFF182230))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            // Search pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xE6242426))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = IosColors.SystemGray)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Search Maps", color = IosColors.SystemGray, fontSize = 15.sp)
                }
            }

            // Simulated Map Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(IosColors.SystemBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Apple Park • Cupertino", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("1 Apple Park Way", color = IosColors.SystemGray, fontSize = 13.sp)
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
fun AppStoreApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("app_store_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Today", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }

                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(IosColors.SystemBlue)
                            .padding(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("FEATURED APP", color = Color(0xCCFFFFFF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Spatial Canvas Studio", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("Create immersive 3D generative art", color = Color.White, fontSize = 14.sp)
                            }
                            Button(
                                onClick = {},
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Text("GET", color = IosColors.SystemBlue, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}
