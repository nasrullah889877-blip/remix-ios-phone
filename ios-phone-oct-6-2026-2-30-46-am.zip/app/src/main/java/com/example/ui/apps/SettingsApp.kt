package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun SettingsApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val isWifiOn by viewModel.isWifiOn.collectAsState()
    val isBluetoothOn by viewModel.isBluetoothOn.collectAsState()
    val isAirplane by viewModel.isAirplaneMode.collectAsState()
    val isTrueTone by viewModel.isTrueTone.collectAsState()
    val isDark by viewModel.isDarkMode.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()

    Box(
        modifier = modifier
            .testTag("settings_app")
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "Settings",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }

                // Apple ID Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1C1C1E))
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(IosColors.SystemBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("NK", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Nasrullah Khan", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text("Apple Account, iCloud+, & Media", color = IosColors.SystemGray, fontSize = 12.sp)
                            }
                            Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = IosColors.SystemGray, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                // Connectivity Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1C1C1E))
                    ) {
                        SettingsToggleRow(
                            icon = Icons.Default.AirplanemodeActive,
                            iconColor = IosColors.SystemOrange,
                            title = "Airplane Mode",
                            isChecked = isAirplane,
                            onCheckedChange = { viewModel.toggleAirplane() }
                        )
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsNavRow(
                            icon = Icons.Default.Wifi,
                            iconColor = IosColors.SystemBlue,
                            title = "Wi-Fi",
                            value = if (isWifiOn) "ApplePark-5G" else "Off",
                            onClick = { viewModel.toggleWifi() }
                        )
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsNavRow(
                            icon = Icons.Default.Bluetooth,
                            iconColor = IosColors.SystemBlue,
                            title = "Bluetooth",
                            value = if (isBluetoothOn) "On" else "Off",
                            onClick = { viewModel.toggleBluetooth() }
                        )
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsNavRow(
                            icon = Icons.Default.SignalCellularAlt,
                            iconColor = IosColors.SystemGreen,
                            title = "Cellular",
                            value = "5G On"
                        )
                    }
                }

                // Display & Brightness
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1C1C1E))
                    ) {
                        SettingsToggleRow(
                            icon = Icons.Default.DarkMode,
                            iconColor = IosColors.SystemIndigo,
                            title = "Dark Appearance",
                            isChecked = isDark,
                            onCheckedChange = { viewModel.toggleDarkMode() }
                        )
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsToggleRow(
                            icon = Icons.Default.WbSunny,
                            iconColor = IosColors.SystemBlue,
                            title = "True Tone",
                            isChecked = isTrueTone,
                            onCheckedChange = { viewModel.toggleTrueTone() }
                        )
                    }
                }

                // Battery Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1C1C1E))
                    ) {
                        SettingsNavRow(
                            icon = Icons.Default.BatteryFull,
                            iconColor = IosColors.SystemGreen,
                            title = "Battery",
                            value = "$batteryLevel% • Maximum Capacity 98%",
                            onClick = { viewModel.toggleCharging() }
                        )
                    }
                }

                // About Device Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1C1C1E))
                    ) {
                        SettingsNavRow(icon = Icons.Default.Info, iconColor = IosColors.SystemGray, title = "Name", value = "iPhone 16 Pro Max")
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsNavRow(icon = Icons.Default.PhoneIphone, iconColor = IosColors.SystemGray, title = "iOS Version", value = "18.1 (22B83)")
                        HorizontalDivider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(start = 54.dp))
                        SettingsNavRow(icon = Icons.Default.Storage, iconColor = IosColors.SystemGray, title = "Capacity", value = "256 GB (184 GB Available)")
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
private fun SettingsNavRow(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    value: String = "",
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(iconColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(text = title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) {
            Text(text = value, color = IosColors.SystemGray, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(6.dp))
        }
        Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = IosColors.SystemGray, modifier = Modifier.size(13.dp))
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(iconColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(text = title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = IosColors.SystemGreen,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF39393D)
            )
        )
    }
}
