package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HomeBar
import com.example.ui.components.IosStatusBar
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun WeatherApp(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val hourlyForecast = listOf(
        "Now" to "72°",
        "10 AM" to "73°",
        "11 AM" to "75°",
        "12 PM" to "76°",
        "1 PM" to "76°",
        "2 PM" to "75°",
        "3 PM" to "74°",
        "4 PM" to "72°",
        "5 PM" to "69°"
    )

    val dailyForecast = listOf(
        Triple("Today", "58°", "76°"),
        Triple("Tue", "56°", "74°"),
        Triple("Wed", "55°", "72°"),
        Triple("Thu", "57°", "75°"),
        Triple("Fri", "59°", "78°"),
        Triple("Sat", "60°", "80°"),
        Triple("Sun", "58°", "75°")
    )

    Box(
        modifier = modifier
            .testTag("weather_app")
            .fillMaxSize()
            .background(IosColors.WeatherGradient)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            IosStatusBar(viewModel = viewModel)

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Hero Cupertino Temperature Header
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp, bottom = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Cupertino", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Normal)
                        Text("72°", color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Thin)
                        Text("Mostly Sunny", color = Color(0xCCFFFFFF), fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("H:76°  L:58°", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                }

                // Hourly Forecast Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0x33000000))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "Sunny conditions will continue for the rest of the day. Wind gusts up to 12 mph.",
                                color = Color(0xE6FFFFFF),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(20.dp)
                            ) {
                                items(hourlyForecast) { (time, temp) ->
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(time, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Icon(
                                            imageVector = Icons.Default.WbSunny,
                                            contentDescription = null,
                                            tint = IosColors.SystemYellow,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(temp, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // 10-Day Forecast Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0x33000000))
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0x80FFFFFF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("10-DAY FORECAST", color = Color(0x80FFFFFF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            dailyForecast.forEach { (day, low, high) ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(day, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(60.dp))
                                    Icon(Icons.Default.WbSunny, contentDescription = null, tint = IosColors.SystemYellow, modifier = Modifier.size(20.dp))
                                    Text(low, color = Color(0x80FFFFFF), fontSize = 15.sp)
                                    // Visual temperature bar
                                    Box(
                                        modifier = Modifier
                                            .width(90.dp)
                                            .height(5.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(IosColors.SystemYellow)
                                    )
                                    Text(high, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // 2x2 Weather Details (UV, Sunset, Wind, Humidity)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WeatherMetricTile(title = "UV INDEX", value = "3", subtitle = "Moderate for the day", modifier = Modifier.weight(1f))
                        WeatherMetricTile(title = "SUNSET", value = "6:52 PM", subtitle = "Sunrise: 7:04 AM", modifier = Modifier.weight(1f))
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WeatherMetricTile(title = "WIND", value = "9 mph", subtitle = "NW • Gusts to 14 mph", modifier = Modifier.weight(1f))
                        WeatherMetricTile(title = "AIR QUALITY", value = "38", subtitle = "AQI - Good", modifier = Modifier.weight(1f))
                    }
                }
            }

            HomeBar(onHomeClick = { viewModel.goHome() })
        }
    }
}

@Composable
private fun WeatherMetricTile(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(130.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x33000000))
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = Color(0x80FFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xCCFFFFFF), fontSize = 12.sp)
        }
    }
}
