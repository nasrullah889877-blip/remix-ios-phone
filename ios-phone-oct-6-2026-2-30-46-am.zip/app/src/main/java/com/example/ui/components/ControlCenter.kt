package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.IosApp
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun ControlCenter(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val isWifiOn by viewModel.isWifiOn.collectAsState()
    val isBluetoothOn by viewModel.isBluetoothOn.collectAsState()
    val isCellularOn by viewModel.isCellularOn.collectAsState()
    val isAirplane by viewModel.isAirplaneMode.collectAsState()
    val isFlashlightOn by viewModel.isFlashlightOn.collectAsState()
    val isDoNotDisturb by viewModel.isDoNotDisturb.collectAsState()
    val isOrientationLocked by viewModel.isOrientationLocked.collectAsState()
    val brightness by viewModel.brightness.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val isPlaying by viewModel.isPlayingMusic.collectAsState()
    val trackIndex by viewModel.currentTrackIndex.collectAsState()
    val track = viewModel.tracks[trackIndex]
    val statusBanner by viewModel.statusBanner.collectAsState()

    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .testTag("control_center_overlay")
            .fillMaxSize()
            .background(Color(0xD9000000))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetY += dragAmount.y
                        if (dragOffsetY < -50f) {
                            viewModel.closeControlCenter()
                        }
                    },
                    onDragEnd = {
                        if (dragOffsetY < -30f) {
                            viewModel.closeControlCenter()
                        }
                        dragOffsetY = 0f
                    }
                )
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                viewModel.closeControlCenter()
            }
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {},
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Grab Handle (for swipe-up to close)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.closeControlCenter() },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .width(44.dp)
                        .height(5.dp)
                        .clip(CircleShape)
                        .background(Color(0x80FFFFFF))
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Swipe up to close",
                    color = Color(0x66FFFFFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Floating Status Pill Banner (dynamic feedback when toggles change)
            AnimatedVisibility(
                visible = statusBanner != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                statusBanner?.let { msg ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xDD2C2C2E))
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // ROW 1: Connectivity Platter (Wi-Fi, Bluetooth, Cellular, Airplane) + Now Playing Platter
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Connectivity Platter
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(164.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x442C2C2E))
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            CcRoundToggle(
                                icon = Icons.Default.AirplanemodeActive,
                                label = "Airplane",
                                isActive = isAirplane,
                                activeColor = IosColors.SystemOrange,
                                onClick = { viewModel.toggleAirplane() }
                            )
                            CcRoundToggle(
                                icon = Icons.Default.SignalCellularAlt,
                                label = "Cellular",
                                isActive = isCellularOn,
                                activeColor = IosColors.SystemGreen,
                                onClick = { viewModel.toggleCellular() }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Dedicated interactive Wi-Fi toggle
                            CcRoundToggle(
                                icon = Icons.Default.Wifi,
                                label = if (isWifiOn) "ApplePark" else "Off",
                                isActive = isWifiOn,
                                activeColor = IosColors.SystemBlue,
                                onClick = { viewModel.toggleWifi() },
                                testTag = "toggle_wifi"
                            )
                            CcRoundToggle(
                                icon = Icons.Default.Bluetooth,
                                label = if (isBluetoothOn) "On" else "Off",
                                isActive = isBluetoothOn,
                                activeColor = IosColors.SystemBlue,
                                onClick = { viewModel.toggleBluetooth() }
                            )
                        }
                    }
                }

                // Now Playing Platter
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(164.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x442C2C2E))
                        .clickable {
                            viewModel.openApp(IosApp.MUSIC)
                            viewModel.closeControlCenter()
                        }
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ios_album_art_1791234504932),
                                contentDescription = "Music Art",
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.title,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = IosColors.SystemGray,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Playback Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.prevTrack() }) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Previous",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            IconButton(
                                onClick = { viewModel.togglePlayPause() },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.Black,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            IconButton(onClick = { viewModel.nextTrack() }) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Next",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }

            // ROW 2: Left 2x2 platter (Orientation Lock, Focus) + Right Vertical Sliders (Brightness & Volume)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left Column: Orientation Lock & Focus
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Interactive Orientation Lock Platter
                        OrientationLockTile(
                            isLocked = isOrientationLocked,
                            onClick = { viewModel.toggleOrientationLock() },
                            modifier = Modifier.weight(1f)
                        )

                        // Screen Mirroring Tile
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(74.dp)
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color(0x442C2C2E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cast,
                                contentDescription = "Screen Mirroring",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    // Focus / Do Not Disturb
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(68.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (isDoNotDisturb) Color.White else Color(0x442C2C2E))
                            .clickable { viewModel.toggleDoNotDisturb() }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bedtime,
                                contentDescription = "Focus",
                                tint = if (isDoNotDisturb) IosColors.SystemIndigo else Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (isDoNotDisturb) "Do Not Disturb" else "Focus",
                                    color = if (isDoNotDisturb) Color.Black else Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isDoNotDisturb) "On" else "Off",
                                    color = if (isDoNotDisturb) Color(0x99000000) else IosColors.SystemGray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Right Column: Vertical Interactive Sliders for Brightness & Volume
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Brightness Slider
                    InteractiveVerticalSlider(
                        value = brightness,
                        onValueChange = { viewModel.setBrightness(it) },
                        icon = when {
                            brightness > 0.65f -> Icons.Default.BrightnessHigh
                            brightness > 0.35f -> Icons.Default.BrightnessMedium
                            else -> Icons.Default.BrightnessLow
                        },
                        label = "${(brightness * 100).toInt()}%",
                        contentDescription = "Brightness Slider",
                        testTag = "slider_brightness",
                        modifier = Modifier.weight(1f)
                    )

                    // Volume Slider
                    InteractiveVerticalSlider(
                        value = volume,
                        onValueChange = { viewModel.setVolume(it) },
                        icon = when {
                            volume > 0.5f -> Icons.Default.VolumeUp
                            volume > 0.05f -> Icons.Default.VolumeDown
                            else -> Icons.Default.VolumeMute
                        },
                        label = "${(volume * 100).toInt()}%",
                        contentDescription = "Volume Slider",
                        testTag = "slider_volume",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ROW 3: Quick Tools (Flashlight, Timer, Calculator, Camera)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CcToolTile(
                    icon = Icons.Default.FlashlightOn,
                    label = "Flashlight",
                    isActive = isFlashlightOn,
                    activeColor = Color.White,
                    onClick = { viewModel.toggleFlashlight() }
                )
                CcToolTile(
                    icon = Icons.Default.Timer,
                    label = "Timer",
                    isActive = false,
                    onClick = {
                        viewModel.openApp(IosApp.CLOCK)
                        viewModel.closeControlCenter()
                    }
                )
                CcToolTile(
                    icon = Icons.Default.Calculate,
                    label = "Calculator",
                    isActive = false,
                    onClick = {
                        viewModel.openApp(IosApp.CALCULATOR)
                        viewModel.closeControlCenter()
                    }
                )
                CcToolTile(
                    icon = Icons.Default.CameraAlt,
                    label = "Camera",
                    isActive = false,
                    onClick = {
                        viewModel.openApp(IosApp.CAMERA)
                        viewModel.closeControlCenter()
                    }
                )
            }
        }
    }
}

@Composable
private fun OrientationLockTile(
    isLocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("toggle_orientation_lock")
            .height(74.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (isLocked) Color.White else Color(0x442C2C2E))
            .clickable { onClick() }
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isLocked) Icons.Default.ScreenLockRotation else Icons.Default.ScreenRotation,
                contentDescription = "Orientation Lock",
                tint = if (isLocked) IosColors.SystemRed else Color.White,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (isLocked) "Locked" else "Lock",
                color = if (isLocked) Color.Black else IosColors.SystemGray,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun CcRoundToggle(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(if (isActive) activeColor else Color(0x33FFFFFF))
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = Color(0xCCFFFFFF),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun InteractiveVerticalSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    icon: ImageVector,
    label: String,
    contentDescription: String,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val animatedValue by animateFloatAsState(
        targetValue = value,
        animationSpec = spring(stiffness = 800f),
        label = "slider_value"
    )

    Box(
        modifier = modifier
            .testTag(testTag)
            .height(154.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0x442C2C2E))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val totalHeight = size.height.toFloat()
                        val fraction = 1f - (offset.y / totalHeight).coerceIn(0f, 1f)
                        onValueChange(fraction)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val totalHeight = size.height.toFloat()
                        val dragY = change.position.y
                        val fraction = 1f - (dragY / totalHeight).coerceIn(0f, 1f)
                        onValueChange(fraction)
                    }
                )
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {}
    ) {
        // Filled portion from bottom upwards
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(animatedValue)
                .align(Alignment.BottomCenter)
                .background(Color.White)
        )

        // Percentage label at top
        Text(
            text = label,
            color = if (animatedValue > 0.85f) Color.Black else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 10.dp)
        )

        // Dynamic Icon at bottom
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (animatedValue > 0.22f) Color.Black else Color.White,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
                .size(26.dp)
        )
    }
}

@Composable
private fun CcToolTile(
    icon: ImageVector,
    label: String,
    isActive: Boolean = false,
    activeColor: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (isActive) activeColor else Color(0x442C2C2E))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) Color.Black else Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}
