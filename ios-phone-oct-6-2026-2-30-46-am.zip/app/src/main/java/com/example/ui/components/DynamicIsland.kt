package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DynamicIslandMode
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel

@Composable
fun DynamicIsland(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val mode by viewModel.dynamicIslandMode.collectAsState()
    val isExpanded by viewModel.isIslandExpanded.collectAsState()
    val isPlaying by viewModel.isPlayingMusic.collectAsState()
    val currentTrackIndex by viewModel.currentTrackIndex.collectAsState()
    val track = viewModel.tracks[currentTrackIndex]
    val isInCall by viewModel.isInCall.collectAsState()
    val callName by viewModel.callContactName.collectAsState()
    val callDuration by viewModel.callDurationSeconds.collectAsState()
    val timerRemaining by viewModel.timerRemainingSeconds.collectAsState()
    val isTimerRunning by viewModel.isTimerRunning.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isCharging.collectAsState()

    val targetWidth by animateDpAsState(
        targetValue = when {
            isExpanded -> 350.dp
            mode == DynamicIslandMode.CALLING -> 210.dp
            mode == DynamicIslandMode.MUSIC && isPlaying -> 190.dp
            mode == DynamicIslandMode.TIMER && timerRemaining > 0 -> 180.dp
            mode == DynamicIslandMode.BATTERY -> 190.dp
            else -> 125.dp
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "islandWidth"
    )

    val targetHeight by animateDpAsState(
        targetValue = when {
            isExpanded -> if (mode == DynamicIslandMode.MUSIC) 180.dp else 140.dp
            else -> 36.dp
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "islandHeight"
    )

    val cornerRadius by animateDpAsState(
        targetValue = if (isExpanded) 36.dp else 24.dp,
        label = "islandCorner"
    )

    Box(
        modifier = modifier
            .testTag("dynamic_island")
            .width(targetWidth)
            .height(targetHeight)
            .clip(RoundedCornerShape(cornerRadius))
            .background(Color.Black)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                if (mode != DynamicIslandMode.COMPACT) {
                    viewModel.toggleIslandExpand()
                }
            }
            .padding(horizontal = if (isExpanded) 16.dp else 10.dp, vertical = if (isExpanded) 14.dp else 6.dp),
        contentAlignment = Alignment.Center
    ) {
        if (!isExpanded) {
            // COMPACT STATE
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (mode) {
                    DynamicIslandMode.CALLING -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Active Call",
                                tint = IosColors.SystemGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format("%02d:%02d", callDuration / 60, callDuration % 60),
                                color = IosColors.SystemGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        // Waveform animation simulation
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Box(modifier = Modifier.size(width = 3.dp, height = 12.dp).clip(CircleShape).background(IosColors.SystemGreen))
                            Box(modifier = Modifier.size(width = 3.dp, height = 16.dp).clip(CircleShape).background(IosColors.SystemGreen))
                            Box(modifier = Modifier.size(width = 3.dp, height = 10.dp).clip(CircleShape).background(IosColors.SystemGreen))
                        }
                    }
                    DynamicIslandMode.MUSIC -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ios_album_art_1791234504932),
                                contentDescription = "Album Art",
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                        }
                        // Equalizer bars
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(width = 3.dp, height = 14.dp).clip(CircleShape).background(IosColors.SystemPink))
                            Box(modifier = Modifier.size(width = 3.dp, height = 18.dp).clip(CircleShape).background(IosColors.SystemPurple))
                            Box(modifier = Modifier.size(width = 3.dp, height = 10.dp).clip(CircleShape).background(IosColors.SystemBlue))
                        }
                    }
                    DynamicIslandMode.TIMER -> {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = "Timer",
                            tint = IosColors.SystemOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = String.format("%02d:%02d", timerRemaining / 60, timerRemaining % 60),
                            color = IosColors.SystemOrange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    DynamicIslandMode.BATTERY -> {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Charging",
                            tint = IosColors.SystemGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "$batteryLevel%",
                            color = IosColors.SystemGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    DynamicIslandMode.COMPACT -> {
                        // Standard sensor cutout + camera dot
                        Box(
                            modifier = Modifier
                                .size(11.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF151515))
                        )
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF112233))
                        )
                    }
                }
            }
        } else {
            // EXPANDED STATE
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                when (mode) {
                    DynamicIslandMode.MUSIC -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ios_album_art_1791234504932),
                                contentDescription = "Album Art",
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = track.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = track.artist,
                                    color = IosColors.SystemGray,
                                    fontSize = 13.sp,
                                    maxLines = 1
                                )
                            }
                            IconButton(onClick = { viewModel.toggleIslandExpand() }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Collapse",
                                    tint = IosColors.SystemGray2,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Progress scrubber
                        Column(modifier = Modifier.fillMaxWidth()) {
                            LinearProgressIndicator(
                                progress = { 0.45f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(CircleShape),
                                color = Color.White,
                                trackColor = Color(0x33FFFFFF)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("1:12", color = IosColors.SystemGray, fontSize = 10.sp)
                                Text("-2:22", color = IosColors.SystemGray, fontSize = 10.sp)
                            }
                        }

                        // Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.prevTrack() }) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Previous",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            IconButton(
                                onClick = { viewModel.togglePlayPause() },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.Black,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            IconButton(onClick = { viewModel.nextTrack() }) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Next",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                    DynamicIslandMode.CALLING -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(IosColors.SystemGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Call",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = callName,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "iPhone Call • " + String.format("%02d:%02d", callDuration / 60, callDuration % 60),
                                        color = IosColors.SystemGray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                            IconButton(
                                onClick = { viewModel.endCall() },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(IosColors.SystemRed)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CallEnd,
                                    contentDescription = "End Call",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                    DynamicIslandMode.TIMER -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Timer",
                                    color = IosColors.SystemGray,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = String.format("%02d:%02d", timerRemaining / 60, timerRemaining % 60),
                                    color = IosColors.SystemOrange,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = { viewModel.pauseResumeTimer() },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(IosColors.SystemOrange)
                                ) {
                                    Icon(
                                        imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Toggle Timer",
                                        tint = Color.Black
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.cancelTimer() },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF333336))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Cancel Timer",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }
                    else -> {
                        Text("iOS System Activity", color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
