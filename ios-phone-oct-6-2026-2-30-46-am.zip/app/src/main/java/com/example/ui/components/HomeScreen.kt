package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.IosApp
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isCharging.collectAsState()

    val homeGridApps = listOf(
        IosApp.CALENDAR,
        IosApp.PHOTOS,
        IosApp.CAMERA,
        IosApp.WEATHER,
        IosApp.CLOCK,
        IosApp.MAPS,
        IosApp.NOTES,
        IosApp.CALCULATOR,
        IosApp.HEALTH,
        IosApp.SETTINGS,
        IosApp.REMINDERS,
        IosApp.APP_STORE
    )

    val dockApps = listOf(
        IosApp.PHONE,
        IosApp.SAFARI,
        IosApp.MESSAGES,
        IosApp.MUSIC
    )

    Box(
        modifier = modifier
            .testTag("home_screen")
            .fillMaxSize()
    ) {
        // Wallpaper
        Image(
            painter = painterResource(id = R.drawable.ios_wallpaper_1791234495056),
            contentDescription = "iOS Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Main Home Screen Layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 8.dp, bottom = 4.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Bar with Dynamic Island
            IosStatusBar(viewModel = viewModel)

            // Content Area: Widgets + App Grid
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Widget Row: 2x2 Weather + 2x2 Battery
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Weather Widget
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(138.dp)
                            .shadow(8.dp, RoundedCornerShape(22.dp))
                            .clip(RoundedCornerShape(22.dp))
                            .background(IosColors.WeatherGradient)
                            .clickable { viewModel.openApp(IosApp.WEATHER) }
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Cupertino", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("72°", color = Color.White, fontWeight = FontWeight.Light, fontSize = 32.sp)
                                }
                                Icon(
                                    imageVector = Icons.Default.WbSunny,
                                    contentDescription = "Sunny",
                                    tint = IosColors.SystemYellow,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Column {
                                Text("Mostly Sunny", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("H:76°  L:58°", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                            }
                        }
                    }

                    // Battery Widget
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(138.dp)
                            .shadow(8.dp, RoundedCornerShape(22.dp))
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0x401C1C1E))
                            .clickable { viewModel.toggleCharging() }
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Batteries", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Icon(
                                    imageVector = if (isCharging) Icons.Default.Bolt else Icons.Default.BatteryFull,
                                    contentDescription = null,
                                    tint = if (isCharging) IosColors.SystemGreen else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BatteryRingItem("iPhone", "$batteryLevel%", if (isCharging) IosColors.SystemGreen else IosColors.SystemGreen)
                                BatteryRingItem("AirPods", "92%", IosColors.SystemGreen)
                                BatteryRingItem("Watch", "74%", IosColors.SystemGreen)
                            }
                        }
                    }
                }

                // 4-Column App Grid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val rows = homeGridApps.chunked(4)
                    rows.forEach { rowApps ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            rowApps.forEach { app ->
                                AppIconItem(
                                    app = app,
                                    onClick = { viewModel.openApp(app) }
                                )
                            }
                            // Empty placeholders to align columns if last row has < 4
                            repeat(4 - rowApps.size) {
                                Spacer(modifier = Modifier.width(62.dp))
                            }
                        }
                    }
                }
            }

            // Bottom Area: Page Dots + Spotlight Search Pill + Frosted Glass Dock + Home Bar
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Spotlight Search Button Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x40000000))
                        .clickable { viewModel.openSpotlight() }
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Search",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Dock (Frosted Glass Container with 4 icons)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .height(86.dp)
                        .shadow(12.dp, RoundedCornerShape(32.dp))
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color(0x35FFFFFF))
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        dockApps.forEach { app ->
                            AppIconItem(
                                app = app,
                                isDock = true,
                                onClick = { viewModel.openApp(app) }
                            )
                        }
                    }
                }

                // Home Indicator Bar
                HomeBar(onHomeClick = { /* already home */ })
            }
        }
    }
}

@Composable
private fun BatteryRingItem(label: String, pct: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2C2C2E)),
                contentAlignment = Alignment.Center
            ) {
                Text(pct, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(label, color = Color(0xCCFFFFFF), fontSize = 10.sp)
    }
}

@Composable
fun AppIconItem(
    app: IosApp,
    isDock: Boolean = false,
    onClick: () -> Unit
) {
    val dayOfMonth = remember {
        val sdf = SimpleDateFormat("d", Locale.getDefault())
        sdf.format(Date())
    }
    val dayOfWeek = remember {
        val sdf = SimpleDateFormat("EEE", Locale.US)
        sdf.format(Date()).uppercase()
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(64.dp)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .shadow(4.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(getAppIconBrush(app)),
            contentAlignment = Alignment.Center
        ) {
            when (app) {
                IosApp.PHONE -> Icon(Icons.Default.Phone, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.MESSAGES -> Icon(Icons.Default.ChatBubble, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.SAFARI -> Icon(Icons.Default.Explore, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.MUSIC -> Icon(Icons.Default.MusicNote, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.CAMERA -> Icon(Icons.Default.CameraAlt, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.PHOTOS -> Icon(Icons.Default.FilterVintage, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.WEATHER -> Icon(Icons.Default.WbSunny, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.CALENDAR -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(dayOfWeek, color = IosColors.SystemRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(dayOfMonth, color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
                IosApp.CLOCK -> Icon(Icons.Default.AccessTime, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.REMINDERS -> Icon(Icons.Default.FormatListBulleted, contentDescription = app.title, tint = IosColors.SystemBlue, modifier = Modifier.size(30.dp))
                IosApp.NOTES -> Icon(Icons.Default.EditNote, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.CALCULATOR -> Icon(Icons.Default.Calculate, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.HEALTH -> Icon(Icons.Default.Favorite, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.SETTINGS -> Icon(Icons.Default.Settings, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
                IosApp.MAPS -> Icon(Icons.Default.Navigation, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(30.dp))
                IosApp.APP_STORE -> Icon(Icons.Default.Storefront, contentDescription = app.title, tint = Color.White, modifier = Modifier.size(32.dp))
            }

            // Notification Badge
            if (app.badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(IosColors.SystemRed),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = app.badgeCount.toString(),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (!isDock) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = app.title,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun getAppIconBrush(app: IosApp): Brush {
    return when (app) {
        IosApp.PHONE -> IosColors.MessagesGradient
        IosApp.MESSAGES -> IosColors.MessagesGradient
        IosApp.SAFARI -> IosColors.SafariGradient
        IosApp.MUSIC -> IosColors.MusicGradient
        IosApp.CAMERA -> IosColors.CameraGradient
        IosApp.PHOTOS -> IosColors.PhotosGradient
        IosApp.WEATHER -> IosColors.WeatherGradient
        IosApp.CALENDAR -> Brush.verticalGradient(listOf(Color.White, Color(0xFFF0F0F2)))
        IosApp.CLOCK -> IosColors.ClockGradient
        IosApp.REMINDERS -> Brush.verticalGradient(listOf(Color.White, Color(0xFFF0F0F2)))
        IosApp.NOTES -> IosColors.NotesGradient
        IosApp.CALCULATOR -> IosColors.CalculatorGradient
        IosApp.HEALTH -> IosColors.HealthGradient
        IosApp.SETTINGS -> IosColors.SettingsGradient
        IosApp.MAPS -> IosColors.MapsGradient
        IosApp.APP_STORE -> IosColors.AppStoreGradient
    }
}
