package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun IosStatusBar(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isCharging.collectAsState()
    val isWifiOn by viewModel.isWifiOn.collectAsState()
    val isCellularOn by viewModel.isCellularOn.collectAsState()
    val isAirplane by viewModel.isAirplaneMode.collectAsState()

    var currentTimeString by remember { mutableStateOf("9:41") }
    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("h:mm", Locale.getDefault())
        currentTimeString = sdf.format(Date())
    }

    Box(
        modifier = modifier
            .testTag("ios_status_bar")
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        // Left: Time
        Row(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    viewModel.lockPhone()
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = currentTimeString,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.2).sp
            )
        }

        // Center: Dynamic Island
        DynamicIsland(viewModel = viewModel)

        // Right: Signal, 5G, Wi-Fi, Battery, Control Center Swipe-down Zone
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    var totalDragY = 0f
                    detectDragGestures(
                        onDragStart = { totalDragY = 0f },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragY += dragAmount.y
                            if (totalDragY > 25f) {
                                viewModel.openControlCenter()
                            }
                        }
                    )
                }
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) {
                    viewModel.openControlCenter()
                },
            horizontalAlignment = Alignment.End
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (isAirplane) {
                    Icon(
                        imageVector = Icons.Default.AirplanemodeActive,
                        contentDescription = "Airplane Mode",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                } else {
                    if (isCellularOn) {
                        Icon(
                            imageVector = Icons.Default.SignalCellular4Bar,
                            contentDescription = "Cellular Signal",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "5G",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (isWifiOn) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Wi-Fi",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                // Battery pill with percentage
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { viewModel.toggleCharging() }
                        .padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isCharging) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Charging",
                            tint = IosColors.SystemGreen,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Text(
                        text = "$batteryLevel%",
                        color = if (isCharging) IosColors.SystemGreen else Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = Icons.Default.BatteryFull,
                        contentDescription = "Battery",
                        tint = if (isCharging) IosColors.SystemGreen else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Subtle iOS Control Center grabber notch line under battery/wifi
            Box(
                modifier = Modifier
                    .padding(top = 2.dp, end = 4.dp)
                    .width(26.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(Color(0x99FFFFFF))
            )
        }
    }
}
