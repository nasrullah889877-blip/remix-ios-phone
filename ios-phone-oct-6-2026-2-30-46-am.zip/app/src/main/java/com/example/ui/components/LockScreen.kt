package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.IosApp
import com.example.model.NotificationItem
import com.example.ui.theme.IosColors
import com.example.viewmodel.IosSystemViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun LockScreen(
    viewModel: IosSystemViewModel,
    modifier: Modifier = Modifier
) {
    val isFaceIdScanning by viewModel.isFaceIdScanning.collectAsState()
    val isFlashlightOn by viewModel.isFlashlightOn.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isCharging.collectAsState()

    var timeString by remember { mutableStateOf("09:41") }
    var dateString by remember { mutableStateOf("Monday, October 5") }

    LaunchedEffect(Unit) {
        val timeSdf = SimpleDateFormat("hh:mm", Locale.getDefault())
        val dateSdf = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        val now = Date()
        timeString = timeSdf.format(now)
        dateString = dateSdf.format(now)
    }

    Box(
        modifier = modifier
            .testTag("lock_screen")
            .fillMaxSize()
    ) {
        // Wallpaper background
        Image(
            painter = painterResource(id = R.drawable.ios_wallpaper_1791234495056),
            contentDescription = "iOS Lock Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Subtle gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x33000000),
                            Color(0x00000000),
                            Color(0x66000000)
                        )
                    )
                )
        )

        // Lock screen content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top: Face ID / Lock Icon
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Icon(
                    imageVector = if (isFaceIdScanning) Icons.Default.Face else Icons.Default.Lock,
                    contentDescription = "Lock Status",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = dateString,
                    color = Color(0xCCFFFFFF),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = timeString,
                    color = Color.White,
                    fontSize = 78.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-2).sp
                )

                // Lock Screen Widgets Row
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Battery Widget
                    LockWidgetPill {
                        Icon(
                            imageVector = if (isCharging) Icons.Default.Bolt else Icons.Default.BatteryFull,
                            contentDescription = null,
                            tint = if (isCharging) IosColors.SystemGreen else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "$batteryLevel%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Weather Widget
                    LockWidgetPill {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = IosColors.SystemYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "72° Sunny", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Calendar Widget
                    LockWidgetPill {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = IosColors.SystemCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "2:00 PM Sync", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Middle: Stacked Notifications
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = "NOTIFICATION CENTER",
                    color = Color(0x80FFFFFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(viewModel.notifications) { item ->
                        LockNotificationCard(
                            item = item,
                            onClick = {
                                viewModel.unlockPhone()
                                viewModel.openApp(item.app)
                            }
                        )
                    }
                }
            }

            // Bottom: Flashlight, "Swipe up to unlock", Camera
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Flashlight button
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isFlashlightOn) Color.White else Color(0x40000000))
                            .clickable { viewModel.toggleFlashlight() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashlightOn,
                            contentDescription = "Flashlight",
                            tint = if (isFlashlightOn) Color.Black else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Camera button
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0x40000000))
                            .clickable {
                                viewModel.unlockPhone()
                                viewModel.openApp(IosApp.CAMERA)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Camera Quick Launch",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Swipe up to unlock indicator
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.unlockPhone() }
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Swipe up to unlock",
                        color = Color(0xB3FFFFFF),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .width(135.dp)
                            .height(5.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }
        }
    }
}

@Composable
private fun LockWidgetPill(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33000000))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun LockNotificationCard(
    item: NotificationItem,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x442C2C2E))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        when (item.app) {
                            IosApp.MESSAGES -> IosColors.SystemGreen
                            IosApp.WEATHER -> IosColors.SystemBlue
                            else -> IosColors.SystemOrange
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (item.app) {
                        IosApp.MESSAGES -> Icons.Default.ChatBubble
                        IosApp.WEATHER -> Icons.Default.WbSunny
                        else -> Icons.Default.Notifications
                    },
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = item.title,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = item.timeAgo,
                        color = Color(0x99FFFFFF),
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.message,
                    color = Color(0xCCFFFFFF),
                    fontSize = 13.sp,
                    maxLines = 2
                )
            }
        }
    }
}
