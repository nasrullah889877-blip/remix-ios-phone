package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object IosColors {
    val SystemBlue = Color(0xFF007AFF)
    val SystemGreen = Color(0xFF34C759)
    val SystemIndigo = Color(0xFF5856D6)
    val SystemOrange = Color(0xFFFF9500)
    val SystemPink = Color(0xFFFF2D55)
    val SystemPurple = Color(0xFFAF52DE)
    val SystemRed = Color(0xFFFF3B30)
    val SystemTeal = Color(0xFF5AC8FA)
    val SystemYellow = Color(0xFFFFCC00)
    val SystemMint = Color(0xFF00C7BE)
    val SystemCyan = Color(0xFF32ADE6)

    // Grays
    val DarkBackground = Color(0xFF000000)
    val DarkSurface = Color(0xFF1C1C1E)
    val DarkElevated = Color(0xFF2C2C2E)
    val DarkCard = Color(0xFF3A3A3C)
    val SystemGray = Color(0xFF8E8E93)
    val SystemGray2 = Color(0xFFAEAEB2)
    val SystemGray3 = Color(0xFFC7C7CC)
    val SystemGray4 = Color(0xFFD1D1D6)
    val SystemGray5 = Color(0xFFE5E5EA)
    val SystemGray6 = Color(0xFFF2F2F7)

    // Frosted Glass / Translucency
    val GlassPill = Color(0x33FFFFFF)
    val GlassCard = Color(0x2EFFFFFF)
    val GlassCardBorder = Color(0x40FFFFFF)
    val GlassDark = Color(0x801C1C1E)
    val GlassDarker = Color(0xCC000000)

    // App Gradients
    val MessagesGradient = Brush.verticalGradient(listOf(Color(0xFF34C759), Color(0xFF30D158)))
    val SafariGradient = Brush.verticalGradient(listOf(Color(0xFF0A84FF), Color(0xFF0062D6)))
    val PhotosGradient = Brush.sweepGradient(
        listOf(
            Color(0xFFFF3B30),
            Color(0xFFFF9500),
            Color(0xFFFFCC00),
            Color(0xFF34C759),
            Color(0xFF007AFF),
            Color(0xFFAF52DE),
            Color(0xFFFF3B30)
        )
    )
    val MusicGradient = Brush.verticalGradient(listOf(Color(0xFFFF2D55), Color(0xFFFA233B), Color(0xFFCC0826)))
    val WeatherGradient = Brush.verticalGradient(listOf(Color(0xFF2B83FA), Color(0xFF1B59C9)))
    val NotesGradient = Brush.verticalGradient(listOf(Color(0xFFFFD60A), Color(0xFFFF9F0A)))
    val SettingsGradient = Brush.verticalGradient(listOf(Color(0xFF8E8E93), Color(0xFF636366)))
    val MapsGradient = Brush.verticalGradient(listOf(Color(0xFF30D158), Color(0xFF0A84FF)))
    val HealthGradient = Brush.verticalGradient(listOf(Color(0xFFFF2D55), Color(0xFFFF375F)))
    val CameraGradient = Brush.verticalGradient(listOf(Color(0xFF48484A), Color(0xFF2C2C2E)))
    val CalculatorGradient = Brush.verticalGradient(listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E)))
    val ClockGradient = Brush.verticalGradient(listOf(Color(0xFF1C1C1E), Color(0xFF000000)))
    val AppStoreGradient = Brush.verticalGradient(listOf(Color(0xFF007AFF), Color(0xFF0051D5)))
}
