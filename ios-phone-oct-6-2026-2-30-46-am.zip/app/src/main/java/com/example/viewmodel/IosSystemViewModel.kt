package com.example.viewmodel

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class IosSystemViewModel : ViewModel() {

    // Lock screen & Authentication
    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _isFaceIdScanning = MutableStateFlow(false)
    val isFaceIdScanning: StateFlow<Boolean> = _isFaceIdScanning.asStateFlow()

    // Navigation & Windowing
    private val _currentApp = MutableStateFlow<IosApp?>(null)
    val currentApp: StateFlow<IosApp?> = _currentApp.asStateFlow()

    private val _isControlCenterOpen = MutableStateFlow(false)
    val isControlCenterOpen: StateFlow<Boolean> = _isControlCenterOpen.asStateFlow()

    private val _isSpotlightOpen = MutableStateFlow(false)
    val isSpotlightOpen: StateFlow<Boolean> = _isSpotlightOpen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Dynamic Island
    private val _dynamicIslandMode = MutableStateFlow(DynamicIslandMode.COMPACT)
    val dynamicIslandMode: StateFlow<DynamicIslandMode> = _dynamicIslandMode.asStateFlow()

    private val _isIslandExpanded = MutableStateFlow(false)
    val isIslandExpanded: StateFlow<Boolean> = _isIslandExpanded.asStateFlow()

    // Control Center Toggles
    private val _isWifiOn = MutableStateFlow(true)
    val isWifiOn: StateFlow<Boolean> = _isWifiOn.asStateFlow()

    private val _isBluetoothOn = MutableStateFlow(true)
    val isBluetoothOn: StateFlow<Boolean> = _isBluetoothOn.asStateFlow()

    private val _isCellularOn = MutableStateFlow(true)
    val isCellularOn: StateFlow<Boolean> = _isCellularOn.asStateFlow()

    private val _isAirplaneMode = MutableStateFlow(false)
    val isAirplaneMode: StateFlow<Boolean> = _isAirplaneMode.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _isDoNotDisturb = MutableStateFlow(false)
    val isDoNotDisturb: StateFlow<Boolean> = _isDoNotDisturb.asStateFlow()

    private val _isOrientationLocked = MutableStateFlow(false)
    val isOrientationLocked: StateFlow<Boolean> = _isOrientationLocked.asStateFlow()

    private val _brightness = MutableStateFlow(0.85f)
    val brightness: StateFlow<Float> = _brightness.asStateFlow()

    private val _volume = MutableStateFlow(0.70f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    private val _isTrueTone = MutableStateFlow(true)
    val isTrueTone: StateFlow<Boolean> = _isTrueTone.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _batteryLevel = MutableStateFlow(94)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    // Music Player State
    val tracks = listOf(
        TrackInfo("Midnight Waves", "Nova & The Echoes", "Spatial Atmosphere", 214),
        TrackInfo("Starlight Horizon", "Cupertino Dreamers", "Silicon Beats", 198),
        TrackInfo("Infinite Flow", "Aether Drift", "Neon Horizons", 245)
    )
    private val _currentTrackIndex = MutableStateFlow(0)
    val currentTrackIndex: StateFlow<Int> = _currentTrackIndex.asStateFlow()

    private val _isPlayingMusic = MutableStateFlow(true)
    val isPlayingMusic: StateFlow<Boolean> = _isPlayingMusic.asStateFlow()

    private val _musicProgress = MutableStateFlow(0.35f)
    val musicProgress: StateFlow<Float> = _musicProgress.asStateFlow()

    // Call state
    private val _dialedNumber = MutableStateFlow("")
    val dialedNumber: StateFlow<String> = _dialedNumber.asStateFlow()

    private val _isInCall = MutableStateFlow(false)
    val isInCall: StateFlow<Boolean> = _isInCall.asStateFlow()

    private val _callContactName = MutableStateFlow("Tim Cook")
    val callContactName: StateFlow<String> = _callContactName.asStateFlow()

    private val _callDurationSeconds = MutableStateFlow(0)
    val callDurationSeconds: StateFlow<Int> = _callDurationSeconds.asStateFlow()

    private var callJob: Job? = null

    // Contacts
    private val _contacts = MutableStateFlow(
        listOf(
            Contact("1", "Tim Cook", "+1 (408) 996-1010", Color(0xFF007AFF), "Apple Park", "10:42 AM"),
            Contact("2", "Craig Federighi", "+1 (408) 555-0199", Color(0xFF34C759), "Hair Force One", "Yesterday"),
            Contact("3", "Sarah Jenkins", "+1 (650) 441-2093", Color(0xFFFF2D55), "Mobile", "Monday"),
            Contact("4", "Alex Rivera", "+1 (212) 883-9912", Color(0xFFFF9500), "Work", "Sunday"),
            Contact("5", "Mom", "+1 (310) 902-1823", Color(0xFFAF52DE), "Home", "Oct 1")
        )
    )
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    // Timer state
    private val _timerTotalSeconds = MutableStateFlow(180)
    val timerTotalSeconds: StateFlow<Int> = _timerTotalSeconds.asStateFlow()

    private val _timerRemainingSeconds = MutableStateFlow(0)
    val timerRemainingSeconds: StateFlow<Int> = _timerRemainingSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private var timerJob: Job? = null

    // Calculator State
    private val _calcDisplay = MutableStateFlow("0")
    val calcDisplay: StateFlow<String> = _calcDisplay.asStateFlow()
    private var firstOperand: Double? = null
    private var pendingOp: String? = null
    private var resetOnNextInput = false

    // Messages State
    private val _messages = MutableStateFlow(
        listOf(
            ChatMessage("1", "Sarah", "Hey! Are you testing the new iPhone mobile interface?", "9:30 AM", false),
            ChatMessage("2", "Me", "Yes! Dynamic Island, Lock Screen, and Control Center look unbelievable! 🚀", "9:32 AM", true),
            ChatMessage("3", "Sarah", "That's awesome! Check out the camera and calculator apps too!", "9:35 AM", false, "❤️")
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Notes State
    private val _notes = MutableStateFlow(
        listOf(
            NoteItem("1", "Keynote Ideas 2026", "• Quantum Glass display\n• Liquid titanium frame\n• 48-hour battery longevity", "Today", true),
            NoteItem("2", "Shopping List", "• Organic avocados\n• Almond milk\n• Honey crisp apples\n• Dark roast espresso beans", "Yesterday"),
            NoteItem("3", "Design Inspiration", "Minimalist glassmorphism, crisp typography, and responsive micro-interactions.", "Sep 28")
        )
    )
    val notes: StateFlow<List<NoteItem>> = _notes.asStateFlow()

    // Alarms State
    private val _alarms = MutableStateFlow(
        listOf(
            AlarmItem("1", "07:00", "AM", "Morning Run", true),
            AlarmItem("2", "08:30", "AM", "Team Sync", true),
            AlarmItem("3", "10:00", "PM", "Bedtime Wind Down", false)
        )
    )
    val alarms: StateFlow<List<AlarmItem>> = _alarms.asStateFlow()

    // Notifications for Lock Screen
    val notifications = listOf(
        NotificationItem("n1", IosApp.MESSAGES, "Messages", "Sarah: That's awesome! Check out the camera...", "2m ago"),
        NotificationItem("n2", IosApp.CALENDAR, "Calendar", "Design Review at 2:00 PM • Cupertino Boardroom", "15m ago"),
        NotificationItem("n3", IosApp.REMINDERS, "Reminders", "Finish the iOS simulation demo", "1h ago")
    )

    init {
        // Dynamic island default behavior
        if (_isPlayingMusic.value) {
            _dynamicIslandMode.value = DynamicIslandMode.MUSIC
        }
    }

    // Lock screen actions
    fun lockPhone() {
        _isLocked.value = true
        _isControlCenterOpen.value = false
        _isSpotlightOpen.value = false
    }

    fun unlockPhone() {
        viewModelScope.launch {
            _isFaceIdScanning.value = true
            delay(400)
            _isFaceIdScanning.value = false
            _isLocked.value = false
        }
    }

    // App Navigation
    fun openApp(app: IosApp) {
        _currentApp.value = app
        _isControlCenterOpen.value = false
        _isSpotlightOpen.value = false
    }

    fun goHome() {
        _currentApp.value = null
        _isControlCenterOpen.value = false
        _isSpotlightOpen.value = false
        _isIslandExpanded.value = false
    }

    // Dynamic Island
    fun toggleIslandExpand() {
        _isIslandExpanded.value = !_isIslandExpanded.value
    }

    fun collapseIsland() {
        _isIslandExpanded.value = false
    }

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun showBanner(message: String) {
        viewModelScope.launch {
            _statusBanner.value = message
            delay(2200)
            if (_statusBanner.value == message) {
                _statusBanner.value = null
            }
        }
    }

    // Control Center
    fun openControlCenter() {
        _isControlCenterOpen.value = true
    }

    fun toggleControlCenter() {
        _isControlCenterOpen.value = !_isControlCenterOpen.value
    }

    fun closeControlCenter() {
        _isControlCenterOpen.value = false
    }

    fun toggleWifi() {
        _isWifiOn.value = !_isWifiOn.value
        showBanner(if (_isWifiOn.value) "Wi-Fi: Connected to ApplePark-5G" else "Wi-Fi: Off")
    }

    fun toggleBluetooth() {
        _isBluetoothOn.value = !_isBluetoothOn.value
        showBanner(if (_isBluetoothOn.value) "Bluetooth: On" else "Bluetooth: Off")
    }

    fun toggleCellular() {
        _isCellularOn.value = !_isCellularOn.value
        showBanner(if (_isCellularOn.value) "Cellular Data: 5G On" else "Cellular Data: Off")
    }

    fun toggleAirplane() {
        _isAirplaneMode.value = !_isAirplaneMode.value
        if (_isAirplaneMode.value) {
            _isWifiOn.value = false
            _isCellularOn.value = false
            showBanner("Airplane Mode: On")
        } else {
            showBanner("Airplane Mode: Off")
        }
    }

    fun toggleFlashlight() {
        _isFlashlightOn.value = !_isFlashlightOn.value
        showBanner(if (_isFlashlightOn.value) "Flashlight: On" else "Flashlight: Off")
    }

    fun toggleDoNotDisturb() {
        _isDoNotDisturb.value = !_isDoNotDisturb.value
        showBanner(if (_isDoNotDisturb.value) "Do Not Disturb: On" else "Do Not Disturb: Off")
    }

    fun toggleOrientationLock() {
        _isOrientationLocked.value = !_isOrientationLocked.value
        showBanner(if (_isOrientationLocked.value) "Portrait Orientation Lock: On" else "Portrait Orientation Lock: Off")
    }

    fun setBrightness(value: Float) {
        _brightness.value = value.coerceIn(0.05f, 1.0f)
    }

    fun setVolume(value: Float) {
        _volume.value = value.coerceIn(0.0f, 1.0f)
    }
    fun toggleTrueTone() { _isTrueTone.value = !_isTrueTone.value }
    fun toggleDarkMode() { _isDarkMode.value = !_isDarkMode.value }
    fun toggleCharging() {
        _isCharging.value = !_isCharging.value
        if (_isCharging.value) {
            _dynamicIslandMode.value = DynamicIslandMode.BATTERY
            viewModelScope.launch {
                delay(3000)
                if (_isInCall.value) {
                    _dynamicIslandMode.value = DynamicIslandMode.CALLING
                } else if (_isTimerRunning.value) {
                    _dynamicIslandMode.value = DynamicIslandMode.TIMER
                } else if (_isPlayingMusic.value) {
                    _dynamicIslandMode.value = DynamicIslandMode.MUSIC
                } else {
                    _dynamicIslandMode.value = DynamicIslandMode.COMPACT
                }
            }
        }
    }

    // Spotlight Search
    fun openSpotlight() { _isSpotlightOpen.value = true }
    fun closeSpotlight() { _isSpotlightOpen.value = false; _searchQuery.value = "" }
    fun updateSearchQuery(query: String) { _searchQuery.value = query }

    // Music Player
    fun togglePlayPause() {
        _isPlayingMusic.value = !_isPlayingMusic.value
        if (_isPlayingMusic.value && !_isInCall.value && !_isTimerRunning.value) {
            _dynamicIslandMode.value = DynamicIslandMode.MUSIC
        }
    }

    fun nextTrack() {
        _currentTrackIndex.value = (_currentTrackIndex.value + 1) % tracks.size
        _musicProgress.value = 0.0f
    }

    fun prevTrack() {
        _currentTrackIndex.value = if (_currentTrackIndex.value > 0) _currentTrackIndex.value - 1 else tracks.size - 1
        _musicProgress.value = 0.0f
    }

    fun seekMusic(fraction: Float) {
        _musicProgress.value = fraction.coerceIn(0f, 1f)
    }

    // Call Functions
    fun appendDial(digit: String) {
        if (_dialedNumber.value.length < 15) {
            _dialedNumber.value += digit
        }
    }

    fun backspaceDial() {
        if (_dialedNumber.value.isNotEmpty()) {
            _dialedNumber.value = _dialedNumber.value.dropLast(1)
        }
    }

    fun startCall(name: String, number: String) {
        _callContactName.value = name.ifEmpty { number.ifEmpty { "Unknown" } }
        _isInCall.value = true
        _callDurationSeconds.value = 0
        _dynamicIslandMode.value = DynamicIslandMode.CALLING
        callJob?.cancel()
        callJob = viewModelScope.launch {
            while (_isInCall.value) {
                delay(1000)
                _callDurationSeconds.value += 1
            }
        }
    }

    fun endCall() {
        _isInCall.value = false
        callJob?.cancel()
        if (_isTimerRunning.value) {
            _dynamicIslandMode.value = DynamicIslandMode.TIMER
        } else if (_isPlayingMusic.value) {
            _dynamicIslandMode.value = DynamicIslandMode.MUSIC
        } else {
            _dynamicIslandMode.value = DynamicIslandMode.COMPACT
        }
    }

    // Timer Functions
    fun startTimer(seconds: Int) {
        _timerTotalSeconds.value = seconds
        _timerRemainingSeconds.value = seconds
        _isTimerRunning.value = true
        if (!_isInCall.value) {
            _dynamicIslandMode.value = DynamicIslandMode.TIMER
        }
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_timerRemainingSeconds.value > 0 && _isTimerRunning.value) {
                delay(1000)
                _timerRemainingSeconds.value -= 1
            }
            _isTimerRunning.value = false
            if (!_isInCall.value) {
                if (_isPlayingMusic.value) {
                    _dynamicIslandMode.value = DynamicIslandMode.MUSIC
                } else {
                    _dynamicIslandMode.value = DynamicIslandMode.COMPACT
                }
            }
        }
    }

    fun pauseResumeTimer() {
        if (_isTimerRunning.value) {
            _isTimerRunning.value = false
            timerJob?.cancel()
        } else if (_timerRemainingSeconds.value > 0) {
            startTimer(_timerRemainingSeconds.value)
        }
    }

    fun cancelTimer() {
        _isTimerRunning.value = false
        _timerRemainingSeconds.value = 0
        timerJob?.cancel()
        if (!_isInCall.value) {
            if (_isPlayingMusic.value) {
                _dynamicIslandMode.value = DynamicIslandMode.MUSIC
            } else {
                _dynamicIslandMode.value = DynamicIslandMode.COMPACT
            }
        }
    }

    fun toggleAlarm(id: String) {
        _alarms.value = _alarms.value.map {
            if (it.id == id) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    // Calculator Functions
    fun onCalcInput(input: String) {
        when (input) {
            "AC" -> {
                _calcDisplay.value = "0"
                firstOperand = null
                pendingOp = null
                resetOnNextInput = false
            }
            "+/-" -> {
                val current = _calcDisplay.value.toDoubleOrNull() ?: 0.0
                val toggled = -current
                _calcDisplay.value = if (toggled % 1.0 == 0.0) toggled.toLong().toString() else toggled.toString()
            }
            "%" -> {
                val current = _calcDisplay.value.toDoubleOrNull() ?: 0.0
                val pct = current / 100.0
                _calcDisplay.value = if (pct % 1.0 == 0.0) pct.toLong().toString() else pct.toString()
            }
            "+", "-", "×", "÷" -> {
                firstOperand = _calcDisplay.value.toDoubleOrNull()
                pendingOp = input
                resetOnNextInput = true
            }
            "=" -> {
                val secondOperand = _calcDisplay.value.toDoubleOrNull()
                if (firstOperand != null && pendingOp != null && secondOperand != null) {
                    val result = when (pendingOp) {
                        "+" -> firstOperand!! + secondOperand
                        "-" -> firstOperand!! - secondOperand
                        "×" -> firstOperand!! * secondOperand
                        "÷" -> if (secondOperand != 0.0) firstOperand!! / secondOperand else Double.NaN
                        else -> secondOperand
                    }
                    _calcDisplay.value = if (result.isNaN()) "Error" else if (result % 1.0 == 0.0) result.toLong().toString() else "%.4f".format(result).trimEnd('0').trimEnd('.')
                    firstOperand = null
                    pendingOp = null
                    resetOnNextInput = true
                }
            }
            "." -> {
                if (resetOnNextInput) {
                    _calcDisplay.value = "0."
                    resetOnNextInput = false
                } else if (!_calcDisplay.value.contains(".")) {
                    _calcDisplay.value += "."
                }
            }
            else -> {
                if (_calcDisplay.value == "0" || resetOnNextInput) {
                    _calcDisplay.value = input
                    resetOnNextInput = false
                } else if (_calcDisplay.value.length < 9) {
                    _calcDisplay.value += input
                }
            }
        }
    }

    // Messages
    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val newMsg = ChatMessage(
            id = System.currentTimeMillis().toString(),
            sender = "Me",
            text = text,
            time = "Now",
            isFromMe = true
        )
        _messages.value = _messages.value + newMsg
        viewModelScope.launch {
            delay(1200)
            val reply = ChatMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "Sarah",
                text = "Love that! The smoothness of this iOS build is super impressive 🔥",
                time = "Now",
                isFromMe = false
            )
            _messages.value = _messages.value + reply
        }
    }

    // Notes
    fun addNote(title: String, content: String) {
        val newNote = NoteItem(
            id = System.currentTimeMillis().toString(),
            title = title.ifEmpty { "New Note" },
            content = content,
            timestamp = "Just now"
        )
        _notes.value = listOf(newNote) + _notes.value
    }

    fun deleteNote(id: String) {
        _notes.value = _notes.value.filter { it.id != id }
    }
}
