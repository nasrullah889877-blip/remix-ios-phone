package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.DynamicIslandMode
import com.example.model.IosApp
import com.example.viewmodel.IosSystemViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("iOS Phone", appName)
  }

  @Test
  fun `ios viewModel navigation and calculator test`() {
    val viewModel = IosSystemViewModel()
    
    // Test app open and close
    viewModel.openApp(IosApp.CALCULATOR)
    assertEquals(IosApp.CALCULATOR, viewModel.currentApp.value)
    viewModel.goHome()
    assertEquals(null, viewModel.currentApp.value)

    // Test calculator arithmetic
    viewModel.onCalcInput("1")
    viewModel.onCalcInput("2")
    viewModel.onCalcInput("+")
    viewModel.onCalcInput("8")
    viewModel.onCalcInput("=")
    assertEquals("20", viewModel.calcDisplay.value)

    // Test lock screen
    viewModel.lockPhone()
    assertTrue(viewModel.isLocked.value)

    // Test control center toggle
    viewModel.toggleControlCenter()
    assertTrue(viewModel.isControlCenterOpen.value)
    viewModel.closeControlCenter()
    assertFalse(viewModel.isControlCenterOpen.value)

    // Test swipe-down opening
    viewModel.openControlCenter()
    assertTrue(viewModel.isControlCenterOpen.value)

    // Test Wi-Fi toggle
    val initialWifi = viewModel.isWifiOn.value
    viewModel.toggleWifi()
    assertEquals(!initialWifi, viewModel.isWifiOn.value)

    // Test Orientation Lock toggle
    val initialOrientationLock = viewModel.isOrientationLocked.value
    viewModel.toggleOrientationLock()
    assertEquals(!initialOrientationLock, viewModel.isOrientationLocked.value)

    // Test Brightness slider
    viewModel.setBrightness(0.55f)
    assertEquals(0.55f, viewModel.brightness.value, 0.001f)

    // Test Volume slider
    viewModel.setVolume(0.82f)
    assertEquals(0.82f, viewModel.volume.value, 0.001f)
  }
}

